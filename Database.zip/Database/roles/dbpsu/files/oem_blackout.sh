#!/bin/bash
# SCRIPT Name: oem_blackout.sh <INSTANCE NAME> <BLACKOUT_TYPE>
# Description: This script is executed to start/stop blackout

# Get Agent Home
AGENT_HOME=`cat /etc/oragchomelist | awk -F: '{print $1}'`
SCRIPT_DIR=$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )
INSTANCE_NAME=$1
BLACKOUT_TYPE=$2
LOG_FILE=${SCRIPT_DIR}/oem_blackout_${INSTANCE_NAME}.log
TARGET_LIST=${SCRIPT_DIR}/target.lst
case $INSTANCE_NAME in
   all)
      echo "Blackout - all"
      ;;
   *)
      # Explicitly report array content.
${AGENT_HOME}/bin/emctl config agent listtargets  | grep PSU | cut -c2- | rev | cut -c2- | rev | sed -e  "s|,||g" > ${TARGET_LIST}
    ;;
esac

start_bo()
{
DATE=`date +%d%m%y%H%M`
BLACKOUT_NAME=${INSTANCE_NAME}_${DATE}
echo "${BLACKOUT_TYPE}ing blackout on $INSTANCE_NAME"
case $INSTANCE_NAME in
   all)
      echo ${BLACKOUT_NAME}
          ${AGENT_HOME}/bin/emctl start blackout ${BLACKOUT_NAME} -nodeLevel
          ;;
   *)
      while read -r line_data;
do
    TARGET_NAME=`echo $line_data | awk '{print $1}'`
    TARGET_TYPE=`echo $line_data | awk '{print $2}'`
    echo "TARGET NAME --> ${TARGET_NAME} ,TARGET TYPE --> ${TARGET_TYPE}"
    ${AGENT_HOME}/bin/emctl start blackout ${BLACKOUT_NAME}_${TARGET_TYPE} ${TARGET_NAME}:${TARGET_TYPE}

done < ${TARGET_LIST}

          ;;
esac
BLACKOUT_STATUS=`echo $?`
if [ ${BLACKOUT_STATUS} -ne 0 ];
then
   echo "Enabling Blackout failed"
   exit 1;
fi;
}

stop_bo()
{
echo "Get the status of blackout"
for BLACKOUT_NAME in `${AGENT_HOME}/bin/emctl status blackout | grep Blackoutname | grep ${INSTANCE_NAME} | awk '{print $3}'`
do
${AGENT_HOME}/bin/emctl stop blackout ${BLACKOUT_NAME}
BLACKOUT_STATUS=`echo $?`
if [ ${BLACKOUT_STATUS} -ne 0 ];
then
   echo "Disabling Blackout failed"
   echo "${AGENT_HOME}/bin/emctl stop blackout ${BLACKOUT_NAME} "
   exit 1;
fi;
done
}

case ${BLACKOUT_TYPE} in
   start)
     echo "starting blackout"
         start_bo >> ${LOG_FILE} 2>&1
         ;;
   stop)
     echo "stopping blackout"
         stop_bo >> ${LOG_FILE} 2>&1
         ;;
   *)
     echo "Incorrect Arguments!!"
         exit 1;
esac

